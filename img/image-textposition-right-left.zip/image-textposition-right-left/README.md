# Image & Text - position right/left

A Pen created on CodePen.io. Original URL: [https://codepen.io/ronnidc/pen/nePwZL](https://codepen.io/ronnidc/pen/nePwZL).

Example. We want to be able to wrap the text below the image. 

The image can float right or left.